import React from "react";

const Footer = () => {
    return (
        <div className="footer">
            Micro frontends demo
        </div>
    )
}

export default Footer;
