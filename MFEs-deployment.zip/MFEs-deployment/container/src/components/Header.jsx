import React from "react";

const Header = () => {
    return (
        <div className="header">
            Microfrontend Host Application
        </div>
    )
}

export default Header;
