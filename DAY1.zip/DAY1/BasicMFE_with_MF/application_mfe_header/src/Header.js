import React from "react";
const Header = () => {
  return (
    <h1 style={{ backgroundColor: "lightblue", padding: "10px" }}>
      Micro Frontend Header !
    </h1>
  );
};
export default Header;
