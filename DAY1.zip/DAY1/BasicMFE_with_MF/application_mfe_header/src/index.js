import React from "react";
import { createRoot } from "react-dom/client";
import Header from "./header";
const rootElement = document.getElementById("root");
const root = createRoot(rootElement);
// App

root.render(<Header />); // instantiate Header component
