import React, { Suspense } from "react";
import { createRoot } from "react-dom/client";
import VueJSFooter from "./VueJS";

const Header = React.lazy(() => import("application_mfe_header/header"));
const CardDetails = React.lazy(() => import("DetailCardInHost/CardDetails"));
const CardShort = React.lazy(() => import("ShortCardInHost/CardShort"));
// App

const App = () => {
  const cardDetails = {
    image: "https://cdn.dummyjson.com/recipe-images/1.webp",
    name: "Classic Margherita Pizza",
    cuisine: "Italian",
    rating: 4.5,
  };

  const cardShortDetails = {
    image: "https://cdn.dummyjson.com/recipe-images/1.webp",
    name: "Classic Margherita Pizza",
  };
  return (
    <div>
      <Suspense fallback={<div>Loading header..</div>}>
        <Header />
      </Suspense>
      <Suspense fallback={<div>Loading Card Details..</div>}>
        <CardDetails data={cardDetails} />
      </Suspense>
      <Suspense fallback={<div>Loading Card Short..</div>}>
        <CardShort data={cardShortDetails} />
      </Suspense>

      <VueJSFooter />
    </div>
  );
};
const rootElement = document.getElementById("root");
const root = createRoot(rootElement);
root.render(<App />); // instantiate Header component
