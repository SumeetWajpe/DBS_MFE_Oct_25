import React, { useEffect, useRef } from "react";
import { mount } from "VueAppInHost/VueApp";
const VueJSFooter = () => {
  const ref = useRef(null);

  useEffect(() => {
    mount(ref.current);
  }, []);
  return <div ref={ref}></div>;
};
export default VueJSFooter;
