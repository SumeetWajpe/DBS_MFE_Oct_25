<template>
  <div>
    <footer>{{ message }}</footer>
  </div>
</template>

<script>
export default {
  setup() {
    return { message: "This is the footer from Vue App" };
  },
};
</script>
